@echo off
cd /d "%~dp0"
"%~dp0ArUcoFurnitureAR.exe" 0
if errorlevel 1 pause

@echo off
cd /d "%~dp0"
"%~dp0ArUcoFurnitureAR.exe" 1
if errorlevel 1 pause
